import React, { useState, useEffect } from "react";
import { FaTableColumns, FaFilter, FaRegTrashCan } from "react-icons/fa6";

import { CiEdit } from "react-icons/ci";
import { RiDeleteBin6Line } from "react-icons/ri";
import { HiMiniWrench } from "react-icons/hi2";
import { BiSolidEdit } from "react-icons/bi";
import { FcSettings } from "react-icons/fc";
import {LuTableOfContents, LuClock9 } from "react-icons/lu";
import { FaPrint } from "react-icons/fa6";
import { FaHome, FaRegFilePdf } from "react-icons/fa";
import { NavLink } from "react-router-dom";
import { IoMdAttach, IoMdArrowDropdown, IoMdArrowDropright } from "react-icons/io";
import { ImCopy } from "react-icons/im";
import { LuRefreshCw } from "react-icons/lu";
import { TiExport, TiPlus } from "react-icons/ti";
import { HiDotsHorizontal } from "react-icons/hi";
const BusinessEntitiesTab = ({ employee }) => {

const [isToolOpen, setIsToolOpen] = useState(false);
const toggleToolDropDown = () => {
    setIsToolOpen(!isToolOpen);
  };
const [isOpen, setIsOpen] = useState(false);
const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };
  const handleRefresh = () => {
    fetchOrganizationalEntities();
  };
  const ColumnDropDown = () => {
    setIsColumnOpen(!isColumnOpen);
  };
  // Add reset columns function
  const resetColumns = () => {
    setVisibleColumns({
      businessEntity: true,
      businessEntityType: true,
      businessEntityId: true,
      parentEntity: true,
      childEntities: true,
      locations: true,
      updatedAt: true,
    });
  };
  const [isColumnOpen, setIsColumnOpen] = useState(false);
    // Update the handleBulkDelete function
    const handleBulkDelete = async () => {
        if (checkedItems.length === 0) return;
    
        if (
          window.confirm(
            `Are you sure you want to delete ${checkedItems.length} selected item(s)?`
          )
        ) {
          setIsLoading(true);
          try {
            await Promise.all(
              checkedItems.map((id) =>
                axios.delete(
                  `http://localhost:8000/api/v1/organizational-entities/${id}`,
                  {
                    headers: {
                      "Content-Type": "application/json",
                    },
                    withCredentials: true,
                  }
                )
              )
            );
    
            const newTotalItems = rows.length - checkedItems.length;
            adjustPageAfterDeletion(newTotalItems);
    
            setCheckedItems([]);
            await fetchOrganizationalEntities();
          } catch (error) {
            console.error("Error deleting entities:", error);
            if (error.response?.status === 401) {
              navigate("/login");
            }
          } finally {
            setIsLoading(false);
          }
        }
      };

  const [currentPage, setCurrentPage] = useState(1);
  const [pageInput, setPageInput] = useState(1);
  const itemsPerPage = 10; // Number of rows per page
  const [checkedItems, setCheckedItems] = useState([]);
  const [rows, setRows] = useState([]);
  const [filters, setFilters] = useState({});
  const [columns, setColumns] = useState([
    { id: "action", label: "action", draggable: true },
    { id: "businessEntityId", label: "Business Entity ID", draggable: true },
    { id: "businessEntity", label: "Business Entity", draggable: true },
    { id: "businessEntityType", label: "Type", draggable: true },
    { id: "parentEntity", label: "Parent Business Entity", draggable: true },
    { id: "childEntities", label: "Child Business Entities", draggable: true },
    { id: "locations", label: "Related Locations", draggable: true },
    { id: "updatedAt", label: "Updated At", draggable: true },
  ]);
  const [draggedColumn, setDraggedColumn] = useState(null);
  const [columnWidths, setColumnWidths] = useState({
    checkbox: 40,
    actions: 100,
    businessEntity: 200,
    businessEntityType: 180,
    businessEntityId: 150,
    parentEntity: 200,
    childEntities: 250,
    locations: 200,
    updatedAt: 180,
  });

  const [visibleColumns, setVisibleColumns] = useState({
    businessEntity: true,
    businessEntityType: true,
    businessEntityId: true,
    parentEntity: true,
    childEntities: true,
    locations: true,
    updatedAt: true,
  });

  // Populate rows when employee changes
  useEffect(() => {
    if (employee && Array.isArray(employee.businessEntities)) {
      setRows(employee.businessEntities);
    } else {
      console.error("businessEntities is not an array:", employee?.businessEntities);
    }
  }, [employee]);

  // Filter rows based on filters
  const filteredRows = rows.filter((row) =>
    Object.entries(filters).every(([key, value]) =>
      value ? String(row[key]).toLowerCase().includes(value.toLowerCase()) : true
    )
  );
  
  // Add column toggle handler
  const handleColumnToggle = (columnName) => {
    setVisibleColumns((prev) => ({
      ...prev,
      [columnName]: !prev[columnName],
    }));
  };
  // Pagination calculations
  const indexOfLastRow = currentPage * itemsPerPage;
  const indexOfFirstRow = indexOfLastRow - itemsPerPage;
  const currentRows = filteredRows.slice(indexOfFirstRow, indexOfLastRow);

  // Pagination handlers
  const handlePageInputChange = (e) => {
    const value = e.target.value;
    setPageInput(value);

    if (e.key === "Enter" || e.type === "blur") {
      const numValue = parseInt(value);
      const maxPage = Math.ceil(filteredRows.length / itemsPerPage);

      if (value === "" || isNaN(numValue) || numValue < 1) {
        setCurrentPage(1);
        setPageInput(1);
      } else if (numValue > maxPage) {
        setCurrentPage(maxPage);
        setPageInput(maxPage);
      } else {
        setCurrentPage(numValue);
        setPageInput(numValue);
      }
    }
  };

  const handleFirstPage = () => {
    setCurrentPage(1);
    setPageInput(1);
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage((prev) => prev - 1);
      setPageInput((prev) => prev - 1);
    }
  };

  const handleNextPage = () => {
    const maxPage = Math.ceil(filteredRows.length / itemsPerPage);
    if (currentPage < maxPage) {
      setCurrentPage((prev) => prev + 1);
      setPageInput((prev) => prev + 1);
    }
  };

  const handleLastPage = () => {
    const lastPage = Math.ceil(filteredRows.length / itemsPerPage);
    setCurrentPage(lastPage);
    setPageInput(lastPage);
  };

  // Checkbox handlers
  const handleSelectAll = (e) => {
    if (e.target.checked) {
      setCheckedItems(currentRows.map((row) => row._id));
    } else {
      setCheckedItems([]);
    }
  };

  const handleCheckboxChange = (id) => {
    setCheckedItems((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  // Drag-and-drop handlers
  const handleDragStart = (e, column) => {
    if (!column.draggable) return;
    setDraggedColumn(column);
    e.target.style.opacity = "0.5";
  };

  const handleDragEnd = (e) => {
    e.target.style.opacity = "1";
    setDraggedColumn(null);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleDrop = (e, targetColumn) => {
    e.preventDefault();
    if (!draggedColumn || !targetColumn.draggable) return;

    const newColumns = [...columns];
    const draggedIdx = columns.findIndex((col) => col.id === draggedColumn.id);
    const targetIdx = columns.findIndex((col) => col.id === targetColumn.id);

    newColumns.splice(draggedIdx, 1);
    newColumns.splice(targetIdx, 0, draggedColumn);

    setColumns(newColumns);
  };

  // Filter handlers
  const handleFilterChange = (columnId, value) => {
    setFilters((prev) => ({
      ...prev,
      [columnId]: value,
    }));
  };

  const handleResizeStart = (e, columnId) => {
    e.preventDefault();
  
    const startX = e.pageX;
    const startWidth = columnWidths[columnId];
  
    const handleMouseMove = (moveEvent) => {
      const newWidth = Math.max(50, startWidth + (moveEvent.pageX - startX));
      setColumnWidths((prev) => ({
        ...prev,
        [columnId]: newWidth,
      }));
    };
  
    const handleMouseUp = () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    };
  
    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseup", handleMouseUp);
  };

  return (
    <div >
      <div className="page-content">
       <div className="main-content2 pt-3">
                  <div className="d-flex align-items-center justify-content-between">
                    <div className="d-flex align-items-center">
                      <span className="header-title">
                        Organizational Entity List{" "}
                      </span>
                      <div className="dropdown">
                        <button
                          className="btn btn-secondary dropdown-toggle border-radius-2"
                          type="button"
                          id="dropdownMenuButton"
                          data-bs-toggle="dropdown"
                          aria-expanded={isOpen}
                          onClick={toggleDropdown}
                        >
                          All Organizational Entities{" "}
                          <IoMdArrowDropdown
                            style={{ width: "20px", height: "20px" }}
                          />
                        </button>
                        <ul
                          className={`dropdown-menu ${isOpen ? "show" : ""}`}
                          aria-labelledby="dropdownMenuButton"
                          style={{
                            "--vz-dropdown-min-width": "15rem",
                            "--vz-dropdown-font-size": "14px;",
                          }}
                        >
                          <li>
                            <NavLink className="dropdown-item">
                              <TiPlus
                                style={{
                                  width: "15px",
                                  height: "15px",
                                  marginBottom: "2px",
                                }}
                              />
                              Create New View
                            </NavLink>
                          </li>
                          <li>
                            <NavLink className="dropdown-item">
                              <IoMdArrowDropright
                                style={{ width: "20px", height: "20px" }}
                              />
                              All Organizational Entities{" "}
                              <BiSolidEdit
                                style={{
                                  width: "15px",
                                  height: "15px",
                                  marginLeft: "20px",
                                }}
                              />
                              <FaTableColumns
                                style={{
                                  width: "15px",
                                  height: "15px",
                                  marginLeft: "5px",
                                }}
                              />
                              <ImCopy
                                style={{
                                  width: "15px",
                                  height: "15px",
                                  marginLeft: "5px",
                                }}
                              />
                            </NavLink>
                          </li>
                          <span className="ms-1">Select Another View...</span>
                          <li>
                            <NavLink className="dropdown-item">
                              Organizational Entity Scorecard
                            </NavLink>
                          </li>
                          <li>
                            <NavLink className="dropdown-item">
                              Department List
                            </NavLink>
                          </li>
                          <li>
                            <NavLink className="dropdown-item">
                              Organizational Units
                            </NavLink>
                          </li>
                          <li>
                            <NavLink className="dropdown-item">
                              Orphaned Organizational Entities
                            </NavLink>
                          </li>
                        </ul>
                      </div>
      
                      <button className="button border-1 ms-1">
                        <FaHome style={{ width: "15px", height: "15px" }} />
                      </button>
                      <button
                        className="button border-1 ms-1"
                        onClick={handleRefresh}
                      >
                        <LuRefreshCw style={{ width: "18px", height: "18px" }} />
                      </button>
                      <span className="dropdown">
                        <button
                          className="btn btn-secondary dropdown-toggle border-radius-2 ms-1"
                          type="button"
                          id="columnDropdown"
                          data-bs-toggle="dropdown"
                          aria-expanded={isColumnOpen}
                          onClick={ColumnDropDown}
                        >
                          <FaTableColumns className="hw-14" />
                        </button>
                        <ul
                          style={{ "--vz-dropdown-min-width": "13rem" }}
                          className={`dropdown-menu ${isColumnOpen ? "show" : ""}`}
                        >
                          <li className="align-items-center justify-content-between d-flex me-1 ms-1">
                            <span className="fw-bold">Columns</span>
                            <a
                              className="blue"
                              onClick={resetColumns}
                              style={{ cursor: "pointer" }}
                            >
                              Reset
                            </a>
                          </li>
                          <li className="dropdown-checkbox">
                            <label>
                              <input
                                type="checkbox"
                                className="ms-2 me-1"
                                checked={visibleColumns.businessEntity}
                                onChange={() => handleColumnToggle("businessEntity")}
                              />
                              Business Entity
                            </label>
                          </li>
                          <li className="dropdown-checkbox">
                            <label>
                              <input
                                type="checkbox"
                                className="ms-2 me-1"
                                checked={visibleColumns.businessEntityType}
                                onChange={() =>
                                  handleColumnToggle("businessEntityType")
                                }
                              />
                              Business Entity Type
                            </label>
                          </li>
                          <li className="dropdown-checkbox">
                            <label>
                              <input
                                type="checkbox"
                                className="ms-2 me-1"
                                checked={visibleColumns.businessEntityId}
                                onChange={() =>
                                  handleColumnToggle("businessEntityId")
                                }
                              />
                              Business Entity ID
                            </label>
                          </li>
                          <li className="dropdown-checkbox">
                            <label>
                              <input
                                type="checkbox"
                                className="ms-2 me-1"
                                checked={visibleColumns.parentEntity}
                                onChange={() => handleColumnToggle("parentEntity")}
                              />
                              Parent Business Entity
                            </label>
                          </li>
                          <li className="dropdown-checkbox">
                            <label>
                              <input
                                type="checkbox"
                                className="ms-2 me-1"
                                checked={visibleColumns.childEntities}
                                onChange={() => handleColumnToggle("childEntities")}
                              />
                              Child Business Entities
                            </label>
                          </li>
                          <li className="dropdown-checkbox">
                            <label>
                              <input
                                type="checkbox"
                                className="ms-2 me-1"
                                checked={visibleColumns.locations}
                                onChange={() => handleColumnToggle("locations")}
                              />
                              Related Locations
                            </label>
                          </li>
                        </ul>
                      </span>
                      <button className="button border-1 ms-1">
                        <FaFilter style={{ width: "15px", height: "15px" }} />
                      </button>
                    </div>
                    <div className="d-flex align-items-center">
                      <NavLink
                        className="button1 border-1"
                        to="/new-organizational-entity"
                      >
                        <TiPlus className="hw-20" />
                        Organizational Entity
                      </NavLink>
                      <button
                        className="button border-1 ms-1"
                        style={{
                          opacity: checkedItems.length > 0 ? 1 : 0.5,
                          cursor: checkedItems.length > 0 ? "pointer" : "default",
                        }}
                        onClick={handleBulkDelete}
                        disabled={checkedItems.length === 0}
                      >
                        <FaRegTrashCan style={{ width: "18px", height: "18px" }} />
                      </button>
                      <button className="button border-1 ms-1">
                        <TiExport style={{ width: "20px", height: "20px" }} />
                      </button>
                      <button className="button border-1 ms-1">
                        <HiDotsHorizontal style={{ width: "20px", height: "20px" }} />
                      </button>
                    </div>
                  </div>
                </div>
        <div className="border-1 mb-3"></div>

        <div className="table-container">
        <div className="pagination-wrapper">
        <div className="d-flex align-items-center gap-3 p-2 justify-content-between">
        <div className="d-flex align-items-center">
            <button className="btn btn-sm btn-outline-secondary" onClick={handleFirstPage}>
              {"<<"}
            </button>
            <button className="btn btn-sm btn-outline-secondary" onClick={handlePrevPage}>
              {"<"}
            </button>
            <span>
              Page {currentPage} of {Math.ceil(filteredRows.length / itemsPerPage)}
            </span>
            <button className="btn btn-sm btn-outline-secondary" onClick={handleNextPage}>
              {">"}
            </button>
            <button className="btn btn-sm btn-outline-secondary" onClick={handleLastPage}>
              {">>"}
            </button>
          </div>
          </div>
          </div>
          <div className="table-container" style={{ overflowX: "auto", overflowY: "auto", maxHeight: "500px" }}>
            <table className="table table-hover">
              <thead>
                <tr>
                  <th>
                    <input
                      type="checkbox"
                      checked={checkedItems.length === currentRows.length && currentRows.length > 0}
                      onChange={handleSelectAll}
                      className="form-check-input"
                    />
                    
                  </th>
                  <th>Action</th>
                  
                  {columns.map((column) => (
                    
                    <th
                      key={column.id}
                      draggable={true}
                      onDragStart={(e) => handleDragStart(e, column)}
                      onDragEnd={handleDragEnd}
                      onDragOver={handleDragOver}
                      onDrop={(e) => handleDrop(e, column)}
                      style={{
                        width: `${columnWidths[column.id]}px`,
                        position: "relative",
                      }}
                    >
                      <div className="d-flex align-items-center justify-content-between">
                        {column.label}
                        <div
                          className="resize-handle"
                          onMouseDown={(e) => handleResizeStart(e, column.id)}
                          style={{
                            cursor: "col-resize",
                            width: "5px",
                            height: "100%",
                            position: "absolute",
                            right: "0",
                            top: "0",
                            backgroundColor: "transparent",
                          }}
                        />
                      </div>
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {currentRows.map((entity) => (
                  <tr key={entity._id}>
                    <td>
                      <input
                        type="checkbox"
                        checked={checkedItems.includes(entity._id)}
                        onChange={() => handleCheckboxChange(entity._id)}
                        className="form-check-input"
                      />
                    </td>
                     <div className="d-flex align-items-center gap-2 justify-content-center">
                                                                <button
                                                                  className="btn btn-sm btn-link p-0"
                                                                  onClick={() => handleEdit(employees._id)}
                                                                  title="Edit"
                                                                >
                                                                  <CiEdit style={{ cursor: "pointer", fontSize: "1.2em", color:'green' }} size={18} />
                                                                </button>
                                                                <button
                                                                  className="btn btn-sm btn-link p-0"
                                                                  onClick={() => handleDelete(employees._id)}
                                                                  title="Delete"
                                                                >
                                                                  <RiDeleteBin6Line className="text-danger" size={18} />
                                                                </button>
                                                              </div>
                    {columns.map((column) => (
                      <td key={`${entity._id}-${column.id}`}>
                        {entity[column.id] || "N/A"}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BusinessEntitiesTab;